## Model-Owned Networking Sample Project

Open the workspace and launch the macOS server. Hit the "Start Server" button in the Mac app to start the server. Launch the iOS client (the server is hardcoded on both sides to localhost and a fixed port). 